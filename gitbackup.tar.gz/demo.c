#include <stdio.h>
 void main()
{
 printf("Hello World");
}

void display()
{
  printf("Display Method");
}
