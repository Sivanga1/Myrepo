class HelloWorld {
    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
        System.out.println( "Line added in GitHub" );
        System.out.println( "Hello From CentOS");
        System.exit( 0 ); //success
    }
} 
